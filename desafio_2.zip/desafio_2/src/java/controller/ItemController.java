package controller;

import dao.ItemDao;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import model.Item;

/**
 *
 * @author junior
 */

@ManagedBean(name = "itemController")
@RequestScoped
public class ItemController {
    
    private Item item;
    private ItemDao dao;
    private List<Item> itens;
    
    @PostConstruct
    public void init(){
        this.item = new Item();
        this.dao = new ItemDao();
        this.itens = this.dao.lista_itens();
    }

    public Item getItem() {
        return item;
    }

    public void setItem(Item item) {
        this.item = item;
    }

    public List<Item> getItens() {
        return itens;
    }

    public void setItens(List<Item> itens) {
        this.itens = itens;
    }
    
    public String salvar(){
        this.dao.salvar(item);
        this.item = new Item();
        return "itens?faces-redirect=true";
    }
    
    public String excluir(Item item){
        this.dao.excluir(item);
        return "itens?faces-redirect=true";
    }
    
}
