package controller;

import dao.ItemDao;
import dao.LancamentoDao;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import model.Item;
import model.Lancamento;
import org.primefaces.event.SelectEvent;

/**
 *
 * @author junior
 */

@ManagedBean(name = "lancamentoController")
@ViewScoped
public class LancamentoController {
    
    private Lancamento lancamento;
    private LancamentoDao dao;
    private List<Lancamento> lancamentos;
    private String txt;
    
    @PostConstruct
    private void init(){
        this.lancamento = new Lancamento();
        this.dao = new LancamentoDao();
        this.lancamentos = this.dao.lista_lancamentos();
        this.txt = "";
    }

    public Lancamento getLancamento() {
        return lancamento;
    }

    public void setLancamento(Lancamento lancamento) {
        this.lancamento = lancamento;
    }

    public List<Lancamento> getLancamentos() {
        return lancamentos;
    }

    public void setLancamentos(List<Lancamento> lancamentos) {
        this.lancamentos = lancamentos;
    }

    public String getTxt() {
        return txt;
    }

    public void setTxt(String txt) {
        this.txt = txt;
    }
    
    
    
    public String salvar(){
        this.dao.salvar(this.lancamento);
        this.lancamento = new Lancamento();
        return "lancamentos?faces-redirect=true";
    }
    
    public String excluir(Lancamento lancamento){
        lancamento.getItens().clear();
        this.dao.excluir(lancamento);
        return "lancamentos?faces-redirect=true";
    }
    
    public List<String> autocomplete(String txt){
        List<String> resultado = new ArrayList<>();
        ItemDao itemdao = new ItemDao();
        List<Item> itens = itemdao.getLikeDescricao(txt);
        for(int i = 0; i < itens.size(); i++){
            resultado.add("ID: "+itens.get(i).getOid()+" Descrição: "+itens.get(i).getDescricao());
        }
        return resultado;
    }
    
    public void itemSelecionado(SelectEvent event){
        String regex = "ID:\\s\\d+";
        Pattern p = Pattern.compile(regex);   // the pattern to search for
        Matcher m = p.matcher(event.getObject().toString());
        if(m.find()){
            int id = Integer.parseInt(m.group(0).replace("ID: ", ""));
            Item item = (Item) new ItemDao().buscarId(Item.class, id);
            // add item
            this.lancamento.getItens().add(item);
            this.atualizarTotal();
            // limpa autocomplete
            this.setTxt("");
        }
    }
    
    public void removerItem(Item item){
        // rm item
        this.lancamento.getItens().remove(item);
        this.atualizarTotal();
    }
    
    public void atualizarTotal(){
        // atualiza valor total
        BigDecimal total = new BigDecimal(BigInteger.ZERO);
        for(Item i: this.lancamento.getItens()){
            total = total.add(i.getValor());
        }
        this.lancamento.setVl_total(total);
    }
}
