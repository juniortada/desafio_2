package model;

import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

/**
 *
 * @author junior
 */

@Entity
@Table(name="Item")
public class Item {
    
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="oid")
    private int oid;
    @Column(name="descricao")
    private String descricao;
    @Column(name="valor", precision = 8, scale = 2, nullable = false)
    private BigDecimal valor;
    
    @ManyToMany(fetch = FetchType.EAGER, mappedBy = "itens")
    private Set<Lancamento> lancamentos = new HashSet<>();

    public int getOid() {
        return oid;
    }

    public void setOid(int oid) {
        this.oid = oid;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public BigDecimal getValor() {
        return valor;
    }

    public void setValor(BigDecimal valor) {
        this.valor = valor;
    }

    public Set<Lancamento> getLancamentos() {
        return lancamentos;
    }

    public void setLancamentos(Set<Lancamento> lancamentos) {
        this.lancamentos = lancamentos;
    }
    
    
    
}
