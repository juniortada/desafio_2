package dao;

import java.util.ArrayList;
import java.util.List;
import model.Item;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import util.HibernateUtil;

/**
 *
 * @author junior
 */

public class ItemDao extends AbstractDao{
    
    public List<Item> lista_itens(){
        List<Item> itens = new ArrayList<>();
        try {
            Session sessao = HibernateUtil.getSessionFactory().openSession();
            sessao.beginTransaction();
            itens = sessao.createQuery("from Item").list();
            sessao.getTransaction().commit();
            sessao.close();
        } catch (HibernateException e) {
            // log erro
        }
        return itens;
    }
    
    public List<Item> getLikeDescricao(String txt){
        List<Item> itens = new ArrayList<>();
        try {
            Session s = abrirSessao();
            String hql = "from Item where descricao like :descricao";
            Query query = s.createQuery(hql);
            query.setString("descricao", "%" + txt + "%");
            itens = query.list();
        } catch (HibernateException e) {
            // log erro
        }
        return itens;
    }
}
