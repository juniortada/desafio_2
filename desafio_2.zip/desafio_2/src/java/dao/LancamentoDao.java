package dao;

import java.util.ArrayList;
import java.util.List;
import model.Lancamento;
import org.hibernate.Session;
import util.HibernateUtil;

/**
 *
 * @author junior
 */

public class LancamentoDao extends AbstractDao{
    
    public List<Lancamento> lista_lancamentos(){
        List<Lancamento> lancamentos = new ArrayList<>();
        try {
            Session sessao = HibernateUtil.getSessionFactory().openSession();
            sessao.beginTransaction();
            lancamentos = sessao.createQuery("from Lancamento").list();
            sessao.getTransaction().commit();
            sessao.close();
        } catch (Exception e) {
        }
        return lancamentos;
    }
}
