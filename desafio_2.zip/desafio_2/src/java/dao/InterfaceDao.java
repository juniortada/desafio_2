package dao;

import org.hibernate.Session;

/**
 *
 * @author junior
 */

public interface InterfaceDao <T>{
    
    Session abrirSessao();
    void fecharSessao();
    void alterar(T obj);
    void excluir(T obj);
    void salvar(T obj);
    Object buscarId(Class classe, int id);
    
}
