package dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import util.HibernateUtil;

/**
 *
 * @author junior
 */
public abstract class AbstractDao implements InterfaceDao{
    
    private Session sessao = null;
    
    @Override
    public Session abrirSessao(){
        try {
            sessao = HibernateUtil.getSessionFactory().openSession();
            sessao.beginTransaction();
            return sessao;
        } catch (HibernateException e) {
            // log erro
            System.out.println("abrirSessao: "+e);
            return null;
        }
    }
    
    @Override
    public void fecharSessao(){
        try {
            if(sessao!=null){
                sessao.close();
            }
        } catch (HibernateException e) {
            // log erro
        }
    }
    
    @Override
    public void alterar(Object obj){
        try {
            abrirSessao();
            this.sessao.flush();
            this.sessao.clear();
            this.sessao.update(obj);
            this.sessao.getTransaction().commit();
            fecharSessao();
            // msg sucesso
        } catch (HibernateException e) {
            // log erro
        }
    }
    
    @Override
    public void excluir(Object obj){
        try {
            abrirSessao();
            this.sessao.flush();
            this.sessao.clear();
            this.sessao.delete(obj);
            this.sessao.getTransaction().commit();
            fecharSessao();
            // msg sucesso
        } catch (HibernateException e) {
            // log erro
        }
    }
    
    @Override
    public void salvar(Object obj){
        try {
            abrirSessao();
            this.sessao.save(obj);
            this.sessao.getTransaction().commit();
            fecharSessao();
            // msg sucesso
        } catch (HibernateException e) {
            // log erro
        }
    }
    
    @Override
    public Object buscarId(Class classe, int id){
        try {
            abrirSessao();
            Object obj = this.sessao.get(classe, id);
            fecharSessao();
            return obj;
        } catch (HibernateException e) {
            return null;
        }
    }
}
